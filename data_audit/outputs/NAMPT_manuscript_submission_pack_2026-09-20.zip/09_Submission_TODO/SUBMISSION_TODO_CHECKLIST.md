# 提交前待办清单（Submission TODO Checklist）

> 生成：2026-09-20（最后一轮审稿复检通过后）；更新：2026-09-20 第二轮（自动化收尾完成）
> 目标期刊：Nature Communications（第一）/ Genome Biology（第二）/ Communications Biology（保底）

## A. 作者与单位 — 需作者确认
- [ ] A1. 核对四位作者姓名拼写与顺序：Yanjing Chen（一作）、Zhenyu Shao、Min Zhang、Yan Zhang（通讯）
- [ ] A2. 核对通讯邮箱：Yan Zhang (zhangyan2021@cupes.edu.cn)；Yanjing Chen (chenyanjing@cupes.edu.cn)
- [ ] A3. 核对四个单位名称与编号（正文头部 1/2/3/4 上标）
- [ ] A4. 确认通讯作者为 Yan Zhang
- [ ] A5. 确认基金声明（当前 "No funding was received for this study"）

## B. 代码与数据归档 — 需作者操作
- [ ] B1. 将仓库上传 GitHub 公开仓库（归档元数据已备：LICENSE/ARCHIVE_README/.zenodo.json/CITATION.cff/requirements.txt）
- [ ] B2. 将代码仓库 URL 填入正文 Code Availability 节（替换 "[GitHub repository URL to be provided upon archiving]"）
- [ ] B3. 在 Zenodo（或 OSF/Figshare）创建归档，获得 DOI
- [ ] B4. 将 Zenodo DOI 填入正文 Code/Data Availability 节（替换 "DOI to be provided upon archiving"）
- [ ] B5. 确认 8 个 Supplementary Data xlsx 与归档一致

## C. 图件与补充材料上传 — 需作者操作
- [ ] C1. 6 张主图 tiff/png（>=300 dpi）上传（本包 02_Figures/submission_assets/）
- [ ] C2. 图源数据（figure_sources/）随稿上传
- [ ] C3. 8 个 Supplementary Data xlsx 上传（本包 03_Supplementary_Data/）
- [ ] C4. 核对 Supplementary Data 编号与 manifest 对应

## D. 投稿文书 — 需作者完成
- [x] D1. Reporting Summary 转填稿：05_Submission_Docs/reporting_summary_formatted.pdf（作者核验后上传官方模板）
- [x] D2. Cover letter 已打磨（含 transfer 意向句）；签名、注明日期后上传
- [ ] D3. 检查 Cover letter 作者列表与正文一致

## E. 投稿系统填写 — 需作者操作
- [x] E1. 复制粘贴文本已备：05_Submission_Docs/submission_system_texts.md
- [ ] E2. 粘贴 Title（8 词）
- [ ] E3. 粘贴 Abstract（141 词）
- [ ] E4. 选择学科分类
- [ ] E5. 推荐/排除审稿人（可选）
- [ ] E6. 利益冲突勾选 none

## F. 投稿前最终自检（全部 ✅ 已通过，2026-09-20 第二轮）
- [x] F1-F10. Title 8 词 / Abstract 141 词 / 引用 1→16 / Refs 16 / 章节 / 图注 / 数字 / 边界 / 无残留 / 最终通读

## G. 后续可选工作
- [ ] G1. Evo2 全量强制重跑（约 30-60 分钟 API）
- [ ] G2. GTEx LD 代理分析
- [ ] G3. 拒稿后转投 Genome Biology / Communications Biology
- [ ] G4. MoTrPAC 蛋白/代谢物验证（不做湿实验，引用他组数据）
- [ ] G5. 系列论文：综述 + 独立 meta 分析

---
*剩余需作者操作：A 核对、B1-B5 归档、C1-C4 上传、D3、E2-E6 系统填写。*
