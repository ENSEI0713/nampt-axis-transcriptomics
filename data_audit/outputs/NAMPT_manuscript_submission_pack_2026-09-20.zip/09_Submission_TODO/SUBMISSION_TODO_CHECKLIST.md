# 提交前待办清单（Submission TODO Checklist）

> 生成：2026-09-20（最后一轮审稿复检通过后）
> 目标期刊：Nature Communications（第一）/ Genome Biology（第二）/ Communications Biology（保底）
> 用途：本文件随投稿包交付；每一项完成后在方框内打勾。全部完成后即可投稿。

---

## A. 作者与单位（投稿系统填写前核对）— 需作者确认

- [ ] A1. 核对四位作者姓名拼写与顺序：Yanjing Chen（一作）、Zhenyu Shao、Min Zhang、Yan Zhang（通讯）
- [ ] A2. 核对通讯邮箱：Yan Zhang (zhangyan2021@cupes.edu.cn)；Yanjing Chen (chenyanjing@cupes.edu.cn)
- [ ] A3. 核对四个单位名称与编号（正文头部 1/2/3/4 上标）
- [ ] A4. 确认通讯作者为 Yan Zhang（投稿系统 Corresponding Author 设置）
- [ ] A5. 确认基金声明（当前 "No funding was received for this study"）

## B. 代码与数据归档（提交前必须完成）— 需作者操作

- [ ] B1. 将 scripts/ 与 data_audit/ 分析代码上传到 GitHub 公开仓库
- [ ] B2. 将代码仓库 URL 填入正文 Code Availability 节（替换 "[GitHub repository URL to be provided upon archiving]"）
- [ ] B3. 在 Zenodo（或 OSF/Figshare）创建归档，获得 DOI
- [ ] B4. 将 Zenodo DOI 填入正文 Code Availability 与 Data Availability 节（替换 "DOI to be provided upon archiving"）
- [ ] B5. 确认 8 个 Supplementary Data xlsx 与 Zenodo 归档数据一致（本包 03_Supplementary_Data/ 为当前版本）

## C. 图件与补充材料上传 — 需作者操作

- [ ] C1. 6 张主图以 tiff 或 png（>=300 dpi）上传（本包 02_Figures/submission_assets/ 已备 4 格式）
- [ ] C2. 图源数据（figure_sources/）随稿上传（NC 鼓励提供源数据）
- [ ] C3. 8 个 Supplementary Data 文件（xlsx）上传（本包 03_Supplementary_Data/）
- [ ] C4. 核对 Supplementary Data 编号与正文/图注 manifest 一一对应（figure_legends_supp_data.md）

## D. 投稿文书 — 需作者完成

- [ ] D1. Reporting Summary：将 05_Submission_Docs/reporting_summary_draft_v1.md 内容转填官方 Nature Portfolio PDF 模板后上传
- [ ] D2. Cover letter：05_Submission_Docs/cover_letter_v1.md 为草稿，签名、注明日期后上传
- [ ] D3. 检查 Cover letter 中作者列表与正文一致

## E. 投稿系统填写 — 需作者操作

- [ ] E1. 选择 Article 类型（NC）
- [ ] E2. Title 框填写："State-dependent NAMPT-axis transcriptional programs in obesity and exercise"（8 词）
- [ ] E3. Abstract 框粘贴：141 词版本（正文 Abstract）
- [ ] E4. 关键词/学科分类（建议：Systems biology / Genomics / Metabolic disorders / Exercise physiology）
- [ ] E5. 推荐/排除审稿人（如有，可选）
- [ ] E6. 利益冲突声明勾选（none）

## F. 投稿前最终自检（建议逐项）

- [ ] F1. Title <= 15 词  OK（8 词）
- [ ] F2. Abstract <= 150 词且无引用  OK（141 词）
- [ ] F3. 正文引用 16 条按首次出现顺序 1→16  OK
- [ ] F4. References 编号制（NC）16 条  OK
- [ ] F5. 章节顺序正确  OK
- [ ] F6. 图注完整（6 图，含统计量） OK
- [ ] F7. 关键数字与落盘 CSV 一致（meta、Evo2 Tier、alpha、r 值） OK
- [ ] F8. 边界声明齐全（mRNA≠eNAMPT、Evo2 非因果、n≤4 方向性、公共数据不诊断） OK
- [ ] F9. 无草稿残留（backtick、审稿代号、TODO） OK
- [ ] F10. 最后一次通读全文（建议在投稿系统预览中执行）

## G. 后续可选工作（不影响本次投稿，供规划）

- [ ] G1. Evo2 全量强制重跑（约 30-60 分钟 API 成本）以确认 Score A/B 稳定性
- [ ] G2. GTEx LD 代理分析，将 Tier C 与常见变异连接（增强外部支持）
- [ ] G3. 如被 NC 拒稿：按审稿意见修订后转投 Genome Biology / Communications Biology
- [ ] G4. 长期：MoTrPAC 蛋白/代谢物验证 eNAMPT/NAD 方向性（已定不做湿实验，可引用他组数据）
- [ ] G5. 系列论文规划：NAMPT-NAD 综述 + 独立 meta 分析（PROGRESS.md 已记）

---

*本清单为投稿交付的一部分，完成后归档。*
