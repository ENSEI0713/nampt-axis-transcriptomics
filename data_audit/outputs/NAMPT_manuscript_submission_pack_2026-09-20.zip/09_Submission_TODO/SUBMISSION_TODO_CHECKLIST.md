# 提交前待办清单（Submission TODO Checklist）— v3 含新手指南

> 更新：2026-09-20 第三轮（首次上传用户专属：新增 GitHub/Zenodo 新手指南）
> 新手先读：05_Submission_Docs/GITHUB_ZENODO_FIRST_TIME_GUIDE.md（含每一步怎么点）

## A. 作者与单位 — 需作者确认
- [ ] A1. 核对四位作者姓名/顺序/单位/邮箱（见正文头部）
- [ ] A2. 确认通讯作者 Yan Zhang
- [ ] A3. 确认基金声明

## B. 代码与数据归档 — 需作者操作（新手看指南第 0-4 步）
- [ ] B1. 注册 GitHub 账号（指南第 0 步）
- [ ] B2. 创建空仓库 nampt-axis-transcriptomics（指南第 1 步，别勾 README/gitignore/license）
- [ ] B3. 设置 git 身份 + 推送（指南第 2 步；git 全局身份未设，需填 GitHub 用户名/邮箱）
- [ ] B4. 检查仓库内容无泄露（指南第 3 步；已复核零 key）
- [ ] B5. Zenodo 关联 GitHub + 发 v1.0.0 release 拿 DOI（指南第 4 步）
- [ ] B6. 把 GitHub URL + Zenodo DOI 填回正文 3 处占位（指南第 5 步；可交回我代填）

## C. 图件与补充材料上传
- [ ] C1. 6 图 tiff/png（>=300dpi）上传（02_Figures/submission_assets/）
- [ ] C2. figure_sources/ 随稿上传
- [ ] C3. 8 个 Supplementary Data xlsx 上传（03_Supplementary_Data/）
- [ ] C4. 核对编号与 manifest 对应

## D. 投稿文书
- [x] D1. Reporting Summary 转填稿已备（reporting_summary_formatted.pdf），核验后上传官方模板
- [x] D2. Cover letter 已打磨（含 transfer 句），签名后上传
- [ ] D3. 核对 Cover letter 作者列表

## E. 投稿系统填写
- [x] E1. 复制粘贴文本已备（submission_system_texts.md）
- [ ] E2-E6. 粘贴 Title/Abstract/分类/审稿人/COI

## F. 最终自检（全部 ✅）
- [x] F1-F10. 全部通过（2026-09-20 第二轮）

## G. 后续可选
- [ ] G1-G5. Evo2 重跑 / GTEx LD / 转投 / MoTrPAC / 系列论文

---
*剩余需作者操作：A、B1-B6（归档，新手约 20-40 分钟）、C、D3、E2-E6。B6 完成后本包需重建。*
